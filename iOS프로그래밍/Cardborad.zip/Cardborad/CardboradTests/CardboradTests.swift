//
//  CardboradTests.swift
//  CardboradTests
//
//  Created by 전지현 on 9/1/25.
//

import Testing
@testable import Cardborad

struct CardboradTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
