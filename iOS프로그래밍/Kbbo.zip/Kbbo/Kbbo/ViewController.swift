//
//  ViewController.swift
//  Kbbo
//
//  Created by 전지현 on 9/15/25.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var faceAlice: UIImageView!
    @IBOutlet weak var faceBob: UIImageView!
    @IBOutlet weak var kbboAlice: UIImageView!
    @IBOutlet weak var kbboBob: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func kbbo(_ sender: UIButton) {
        var rnBob, rnAlice, result : Int
        rnBob = Int(arc4random() % 3)
        rnAlice = Int(arc4random() % 3)
        result = 0;
        switch rnBob
        {
        case 0:
            kbboBob.image = UIImage(named: "kawi.png")
            if rnAlice == 0 {
                result = 0 // soso
            } else if rnAlice == 1 {
                result = 1 // bob lose
            } else {
                result = 2 // bob win
            }
            NSLog("case 0")
        case 1:
            kbboBob.image = UIImage(named: "bawi.png")
            if rnAlice == 0 {
                result = 2 // bob win
            } else if rnAlice == 1 {
                result = 0 // soso
            } else {
                result = 1; // bob lose
            }
            NSLog("case 1")
        case 2:
            kbboBob.image = UIImage(named: "bo.png")
            if rnAlice == 0 {
                result = 1 // bob lose
            } else if rnAlice == 1 {
                result = 2
            } else {
                result = 0
            }
            NSLog("case 2")
        default:
            break
        }
        NSLog("rnBob %d, rnAlice %d, result %d", rnBob, rnAlice, result);
        switch result {
        case 0: // soso
            faceBob.image = UIImage(named: "soso.png")
            faceAlice.image = UIImage(named:"soso.png")
        case 1: // bob lose
            faceBob.image = UIImage(named: "angry.png")
            faceAlice.image = UIImage(named:"happy.png")
        case 2: // bob win
            faceBob.image = UIImage(named: "happy.png")
            faceAlice.image = UIImage(named:"angry.png")
        default:
            break
        }
        switch rnAlice {
        case 0:
        kbboAlice.image = UIImage(named: "kawi.png")
        case 1:
        kbboAlice.image = UIImage(named: "bawi.png")
        case 2:
        kbboAlice.image = UIImage(named: "bo.png")
        default:
        break
        }
        
        
        
    }
    
}
