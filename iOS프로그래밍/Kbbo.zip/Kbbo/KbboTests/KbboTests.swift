//
//  KbboTests.swift
//  KbboTests
//
//  Created by 전지현 on 9/15/25.
//

import Testing
@testable import Kbbo

struct KbboTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
