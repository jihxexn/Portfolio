//
//  NameCard3Tests.swift
//  NameCard3Tests
//
//  Created by 전지현 on 9/8/25.
//

import Testing
@testable import NameCard3

struct NameCard3Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
