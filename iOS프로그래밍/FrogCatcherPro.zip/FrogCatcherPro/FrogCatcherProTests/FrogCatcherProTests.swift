//
//  FrogCatcherProTests.swift
//  FrogCatcherProTests
//
//  Created by 전지현 on 10/13/25.
//

import Testing
@testable import FrogCatcherPro

struct FrogCatcherProTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
