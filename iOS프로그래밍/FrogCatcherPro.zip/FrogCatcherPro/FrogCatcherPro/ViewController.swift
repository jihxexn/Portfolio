//
//  ViewController.swift
//  FrogCatcherPro
//
//  Created by 전지현 on 10/13/25.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var backButton: UIButton!
    
    @IBOutlet weak var currentPlayer: UILabel!
    @IBOutlet weak var frogCount: UILabel!
    @IBOutlet weak var elapsedTime: UILabel!
    
    @IBOutlet weak var name1: UIButton!
    @IBOutlet weak var name2: UIButton!
    @IBOutlet weak var name3: UIButton!
    
    @IBOutlet weak var score1: UILabel!
    @IBOutlet weak var score2: UILabel!
    @IBOutlet weak var score3: UILabel!
    
    @IBOutlet weak var holeButton1: UIButton!
    @IBOutlet weak var holeButton2: UIButton!
    @IBOutlet weak var holeButton3: UIButton!
    @IBOutlet weak var holeButton4: UIButton!
    @IBOutlet weak var holeButton5: UIButton!
    
    var buttonArray: Array<UIButton> = []
    var mark: Array<String> = []
    var frog: Array<UIImage> = []
    var startTime: Date = Date()
    var elapTime = 0.0
    var num0fFrog = 0
    var catchFrog: UIImage! = UIImage(named:"catch.png")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        buttonArray = [holeButton1, holeButton2, holeButton3, holeButton4, holeButton5]
        mark = ["1", "2", "3", "4", "5"]
        for i in 0..<5 {
            buttonArray[i].setTitle(mark[i], for: UIControl.State.normal)
        }
        num0fFrog = 0
        // Do any additional setup after loading the view.
    }
    func nextGame() {
        num0fFrog = 10
        frogCount.text = String(format:"%d", num0fFrog)
        elapsedTime.text = "0"
        for i in 0..<5 {
            buttonArray[i].setTitle(mark[i], for: UIControl.State.normal)
            buttonArray[i].setTitleColor(UIColor.white, for: UIControl.State.normal)
        }
    }

    @IBAction func backButtonPressed(_ sender: UIButton) {
    }
    
    @IBAction func player1Start(_ sender: UIButton) {
        if num0fFrog == 0 {
            currentPlayer.text = name1.currentTitle
            startTime = Date()
            nextGame()
            buttonUpdate()
        }
    }
    @IBAction func player2Start(_ sender: UIButton) {
        if num0fFrog == 0 {
            currentPlayer.text = name2.currentTitle
            startTime = Date()
            nextGame()
            buttonUpdate()
        }
        
    }
    @IBAction func player3Start(_ sender: UIButton) {
        if num0fFrog == 0 {
            currentPlayer.text = name3.currentTitle
            startTime = Date()
            nextGame()
            buttonUpdate()
        }
    }
    @IBAction func holeButtonPressed(_ sender: UIButton) {
        var elap = 0.0
        if num0fFrog != 0 { // Game is on
            if sender.currentTitle == "X" {
                num0fFrog -= 1
                if num0fFrog <= 0 {
                    num0fFrog = 0
                    elapTime = Date().timeIntervalSince(startTime)
                    rankUpdate()
                }
                else {
                    elap = Date().timeIntervalSince(startTime)
                    elapsedTime.text = String(format: "%.2f", elap)
                    buttonUpdate()
                }
                frogCount.text = String(format: "%d", num0fFrog)
            }
        }
    }
    func buttonUpdate() {
        let rndNum = arc4random() % 5
        for i in 0..<5 {
            buttonArray[i].setTitle(mark[i], for: UIControl.State.normal)
            buttonArray[i].setTitleColor(UIColor.white, for: UIControl.State.normal)
            buttonArray[i].setBackgroundImage(UIImage(named: "Hole.png"), for: UIControl.State.normal)
        }
        buttonArray[Int(rndNum)].setTitle("X", for: UIControl.State.normal)
        buttonArray[Int(rndNum)].setBackgroundImage(UIImage(named: "catch.png"), for:
                                                        UIControl.State.normal)
    }
    func rankUpdate() {
        let score = String(format: "%.2f", elapTime)
        elapsedTime.text = score
        elapTime = 0.0 // reset
        if currentPlayer.text == name1.currentTitle {
            score1.text = score
        } else if currentPlayer.text == name2.currentTitle {
            score2.text = score
        } else if currentPlayer.text == name3.currentTitle {
            score3.text = score
        }
    }
}


