//
//  ViewController.swift
//  Beep
//
//  Created by 전지현 on 11/3/25.
//

import UIKit

import AudioToolbox

class ViewController: UIViewController {
    var catchBeep: SystemSoundID = 0
    var wrongBeep: SystemSoundID = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        var path: NSURL
        path = NSURL(fileURLWithPath: Bundle.main.path(forResource: "Boing", ofType: "aiff")!)
        AudioServicesCreateSystemSoundID(path, &catchBeep)
        path = NSURL(fileURLWithPath: Bundle.main.path(forResource: "Indigo", ofType: "aiff")!)
        AudioServicesCreateSystemSoundID(path, &wrongBeep)
    }

    @IBAction func playCatchBeep(_ sender: UIButton) {
        AudioServicesPlayAlertSound(catchBeep)
    }
    
    @IBAction func playWrongBeep(_ sender: UIButton) {
        AudioServicesPlayAlertSound(wrongBeep)
    }
}

