//
//  BeepTests.swift
//  BeepTests
//
//  Created by 전지현 on 11/3/25.
//

import Testing
@testable import Beep

struct BeepTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
