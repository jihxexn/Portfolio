//
//  ViewController.swift
//  Name Card 2
//
//  Created by 전지현 on 9/8/25.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var hakbun: UILabel!
    @IBOutlet weak var photo: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func buttonOne(_ sender: Any) {
        name.text="전지현"
        hakbun.text="20213271"
        photo.image=UIImage(named:"20250908.png")
    }
}

