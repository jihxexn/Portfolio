//
//  Name_Card_2Tests.swift
//  Name Card 2Tests
//
//  Created by 전지현 on 9/8/25.
//

import Testing
@testable import Name_Card_2

struct Name_Card_2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
