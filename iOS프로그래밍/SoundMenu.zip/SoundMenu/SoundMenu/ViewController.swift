//
//  ViewController.swift
//  SoundMenu
//
//  Created by 전지현 on 11/10/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

