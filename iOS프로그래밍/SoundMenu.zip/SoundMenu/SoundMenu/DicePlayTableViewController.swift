//
//  DicePlayTableViewController.swift
//  SoundMenu
//
//  Created by 전지현 on 11/10/25.
//
/* 수업
import UIKit

class DicePlayTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

   
    
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 6
    }
    override func tableView(_
    tableView: UITableView, cellForRowAt indexPath: IndexPath) ->
    UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DiceCell", for: indexPath)
        // Configure the cell...
        cell.textLabel!.text = String(format: "Cell %d", indexPath.row)
        
        return cell
    }
    
    
    
    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    //MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
     */
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "DicePlaySegue" {
            let vc = segue.destination as! DicePlayViewController
            let _sender = sender as! UITableViewCell
        vc.text = _sender.textLabel!.text!
        }
    }
    


} 수업
*/

/*

import UIKit
import AudioToolbox

class DicePlayTableViewController: UITableViewController {
    
    let sounds = ["Boing", "Indigo", "Laugh", "Monkey", "Single Click", "Uh Oh"]
    
    // 사운드별 재생 횟수 저장
    var playCount = [0, 0, 0, 0, 0, 0]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "DicePlay"
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sounds.count
    }
    
    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath)
        -> UITableViewCell {
            
        let cell = tableView.dequeueReusableCell(withIdentifier: "SoundCell",
                                                 for: indexPath)
        cell.textLabel?.text = sounds[indexPath.row]
        return cell
    }
    
    override func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath) {
        
        let vc = storyboard?.instantiateViewController(
            withIdentifier: "DicePlayViewController"
        ) as! DicePlayViewController
        
        // 데이터 전달
        vc.soundName = sounds[indexPath.row]
        vc.cellIndex = indexPath.row
        vc.playCount = playCount
        
        vc.delegate = self
        
    }
}

extension DicePlayTableViewController: PlayCountDelegate {
    func updateCount(index: Int, count: Int) {
        playCount[index] = count
    }
}
*/

import UIKit

class DicePlayTableViewController: UITableViewController {
    
    let sounds = ["Boing", "Indigo", "Laugh", "Monkey", "Single Click", "Uh Oh"]
    var playCount = [0, 0, 0, 0, 0, 0]   // 재생 횟수 저장
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "DicePlay"
    }
    
    override func tableView(_ tableView: UITableView,
                            numberOfRowsInSection section: Int) -> Int {
        return sounds.count
    }
    
    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath)
        -> UITableViewCell {
            
        let cell = tableView.dequeueReusableCell(withIdentifier: "SoundCell", for: indexPath)
        cell.textLabel?.text = sounds[indexPath.row]
        return cell
    }
    
    // 화면 이동 + 데이터 전달
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ToDicePlay" {
            if let vc = segue.destination as? DicePlayViewController,
               let index = tableView.indexPathForSelectedRow?.row {
                
                vc.soundName = sounds[index]
                vc.cellIndex = index
                vc.playCount = playCount
                vc.delegate = self
            }
        }
    }
}

extension DicePlayTableViewController: PlayCountDelegate {
    func updateCount(index: Int, count: Int) {
        playCount[index] = count
    }
}
