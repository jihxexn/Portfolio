//
//  DicePlayViewController.swift
//  SoundMenu
//
//  Created by 전지현 on 11/10/25.
//

/* 여기 import UIKit

class DicePlayViewController: UIViewController {

    
    var text:String = ""
    @IBOutlet weak var cellNo: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cellNo.text = text
        // Do any additional setup after loading the view.
    }
    
여기 */
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    

}
*/


import UIKit
import AudioToolbox

protocol PlayCountDelegate {
    func updateCount(index: Int, count: Int)
}

class DicePlayViewController: UIViewController {

    @IBOutlet weak var cellNoLabel: UILabel!
    @IBOutlet weak var soundNameLabel: UILabel!
    
    var soundName: String = ""
    var cellIndex: Int = 0
    var playCount: [Int] = [0, 0, 0, 0, 0, 0]
    
    var delegate: PlayCountDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 사운드 이름 표시
        soundNameLabel.text = soundName
        
        // 처음 들어올 때 현재 카운트 표시
        cellNoLabel.text = "Cell No: \(playCount[cellIndex])"
    }

    @IBAction func playSoundButtonTapped(_ sender: UIButton) {
        playSoundEffect()
        
        // 재생 횟수 증가
        playCount[cellIndex] += 1
        
        // 화면 업데이트
        cellNoLabel.text = "Cell No: \(playCount[cellIndex])"
        
        // 메인 테이블뷰에게 전달
        delegate?.updateCount(index: cellIndex, count: playCount[cellIndex])
    }
    
    func playSoundEffect() {
        var soundId: SystemSoundID = 0
        
        switch soundName {
        case "Boing":        soundId = 1104
        case "Indigo":       soundId = 1107
        case "Laugh":        soundId = 1110
        case "Monkey":       soundId = 1023
        case "Single Click": soundId = 1103
        case "Uh Oh":        soundId = 1006
        default:             soundId = 1104
        }
        
        AudioServicesPlaySystemSound(soundId)
    }
}
