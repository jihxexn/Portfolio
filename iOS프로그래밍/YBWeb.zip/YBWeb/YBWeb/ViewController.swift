//
//  ViewController.swift
//  YBWeb
//
//  Created by 전지현 on 12/1/25.
//

import UIKit
import WebKit

class ViewController: UIViewController,WKNavigationDelegate {

    @IBOutlet weak var url: UITextField!
    @IBOutlet weak var web: WKWebView!
    
    func loadWebPage(_ url: String) {
        let myUrl = URL(string: url)
        let myRequest = URLRequest(url: myUrl!)
        web.load(myRequest)
    }
    override func viewDidLoad() {
        super.viewDidLoad()        // Do any additional setup after loading the view.
        web.navigationDelegate = self
        loadWebPage("http://naver.com")
    }
    func checkUrl(_ url: String) -> String {
            var strUrl=url
            let flag=strUrl.hasPrefix("https://")
            if !flag {
                strUrl = "https://" + strUrl
            }
            return strUrl
        }
    func webView(
    _
    webView: WKWebView, didCommit navigation: WKNavigation!) {
    }
    func webView(
    _
    webView: WKWebView, didFinish navigation: WKNavigation!) {
    }
    func webView(
    _
    webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {}
    
    @IBAction func onGo(_ sender: UIButton) {
        let myUrl = checkUrl(url.text!)
        url.text=""
        loadWebPage(myUrl)
    }
    
    @IBAction func goBack(_ sender: UIButton) {
        web.goBack()
    }
    
    @IBAction func goForward(_ sender: UIButton) {
        web.goForward()
    }
    @IBAction func reload(_ sender: UIButton) {
        web.reload()
    }
    @IBAction func stopLoading(_ sender: UIButton) {
        web.stopLoading()
    }
}

