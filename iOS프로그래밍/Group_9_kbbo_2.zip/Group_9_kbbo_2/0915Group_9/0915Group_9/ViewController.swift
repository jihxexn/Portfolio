//
//  ViewController.swift
//  0915Group_9
//
//  Created by 전지현 on 9/19/25.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var faceAlice: UIImageView!
    @IBOutlet weak var faceBob: UIImageView!
    @IBOutlet weak var kbboAlice: UIImageView!
    @IBOutlet weak var kbboBob: UIImageView!
    var rnAlice : Int = 0
    var rnBob : Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func Ahand(_ sender: UIButton) {
        rnAlice = Int(arc4random()%3)
        if rnAlice == 0 {
            kbboAlice.image = UIImage(named: "kawi.png")
        } else if rnAlice == 1 {
            kbboAlice.image = UIImage(named: "bawi.png")
        } else {
            kbboAlice.image = UIImage(named: "bo.png")
        }
        if kbboBob.image != nil {
            checkResult()
        }
    }
    
    
    
    @IBAction func Bhand(_ sender: UIButton) {
        rnBob = Int(arc4random() % 3)
        if rnBob == 0 {
            kbboBob.image = UIImage(named: "kawi.png")
        } else if rnBob == 1 {
            kbboBob.image = UIImage(named: "bawi.png")
        } else {
            kbboBob.image = UIImage(named: "bo.png")
        }
        
        if kbboAlice.image !=  nil {
            checkResult()
        }
    }
        func checkResult() {
            var result = 0
            if rnAlice == rnBob {
                result = 0
            } else if (rnAlice == 0 && rnBob == 2) || (rnAlice == 1 && rnBob == 0) || (rnAlice == 2 && rnBob == 1) {
                result = 1   // Alice 승
            } else {
                result = 2   // Bob 승
            }
            
            if result == 0 {
                faceAlice.image = UIImage(named: "soso.png")
                faceBob.image = UIImage(named: "soso.png")
            } else if result == 1 {
                faceAlice.image = UIImage(named: "happy.png")
                faceBob.image = UIImage(named: "angry.png")
            } else {
                faceAlice.image = UIImage(named: "angry.png")
                faceBob.image = UIImage(named: "happy.png")
            }
        }
    }

