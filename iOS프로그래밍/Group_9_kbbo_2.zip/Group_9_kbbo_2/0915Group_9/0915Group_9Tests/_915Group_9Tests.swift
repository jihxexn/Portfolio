//
//  _915Group_9Tests.swift
//  0915Group_9Tests
//
//  Created by 전지현 on 9/19/25.
//

import Testing
@testable import _915Group_9

struct _915Group_9Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
