//
//  NameCardTests.swift
//  NameCardTests
//
//  Created by 전지현 on 9/8/25.
//

import Testing
@testable import NameCard

struct NameCardTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
