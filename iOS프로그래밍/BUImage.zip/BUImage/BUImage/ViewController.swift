//
//  ViewController.swift
//  BUImage
//
//  Created by 전지현 on 12/1/25.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var play: UIBarButtonItem!
    @IBOutlet weak var page: UIBarButtonItem!
    @IBOutlet weak var left: UIBarButtonItem!
    @IBOutlet weak var right: UIBarButtonItem!
    
    var imgs : Array<UIImage> = []
    var currentSel : Int = 0
    var speed : Float = 0
    
    var frog1Img = UIImage(named: "frog1.png")
    var frog2Img = UIImage(named: "frog2.png")
    var frog3Img = UIImage(named: "frog3.png")
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        imgs = [frog1Img!, frog2Img!, frog3Img!]
        imgView.animationImages = imgs
        currentSel = 0
        speed = 0.5
    }

    @IBAction func onSpeed(_ sender: UISlider) {
        speed = sender.value
        if imgView.isAnimating {
            imgView.animationDuration = TimeInterval(speed * 5.0)
            imgView.startAnimating()
        }
    }
    
    @IBAction func onPlayStop(_ sender: UIBarButtonItem) {
        if imgView.isAnimating {
            imgView.stopAnimating()
            play.title = "Play"
        } else {
            imgView.animationDuration = TimeInterval(speed * 5.0)
            imgView.animationRepeatCount = 0
            imgView.startAnimating()
            play.title = "Stop"
        }
    
    }
    @IBAction func onPrev(_ sender: UIBarButtonItem) {
        if imgView.isAnimating {
            imgView.stopAnimating()
            play.title = "Play"
        }
        
        // 이전 이미지로 이동 (순환)
        currentSel = (currentSel - 1 + imgs.count) % imgs.count
        imgView.image = imgs[currentSel]
        
        // 페이지 표시
        page.title = "\(currentSel + 1)"
    }
    @IBAction func onNext(_ sender: UIBarButtonItem) {
        if imgView.isAnimating {
            imgView.stopAnimating()
            play.title = "Play"
        }
        
        // 다음 이미지로 이동 (순환)
        currentSel = (currentSel + 1) % imgs.count
        imgView.image = imgs[currentSel]
        
        // 페이지 표시
        page.title = "\(currentSel + 1)"
    }
}

