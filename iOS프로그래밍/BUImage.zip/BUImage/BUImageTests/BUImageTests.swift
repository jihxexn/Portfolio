//
//  BUImageTests.swift
//  BUImageTests
//
//  Created by 전지현 on 12/1/25.
//

import Testing
@testable import BUImage

struct BUImageTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
