//
//  FrogTests.swift
//  FrogTests
//
//  Created by 전지현 on 9/29/25.
//

import Testing
@testable import Frog

struct FrogTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
