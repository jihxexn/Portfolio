//
//  ViewController.swift
//  Frog
//
//  Created by 전지현 on 9/29/25.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var displayFrogCount: UILabel!
    @IBOutlet weak var displayInterval: UILabel!
    
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button4: UIButton!
    @IBOutlet weak var button5: UIButton!
    
    var buttonArray: Array<UIButton> = []
    var mark: Array<String> = []
    var frog: Array<UIImage> = []
    var frogCount = 0
    var startTime = Date()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        buttonArray = [button1, button2, button3, button4, button5]
        mark = ["1", "2", "3", "4", "5"]
        button1.setTitle(mark[0], for: UIControl.State.normal)
        button2.setTitle(mark[1], for: UIControl.State.normal)
        button3.setTitle(mark[2], for: UIControl.State.normal)
        button4.setTitle(mark[3], for: UIControl.State.normal)
        button5.setTitle(mark[4], for: UIControl.State.normal)
    }
    
    @IBAction func pressStart(_ sender: UIButton) {
        if frogCount == 0 { // Game Over check
            startTime = Date() // get current time
            nextGame()
            buttonUpdate()
        }
    }
           
  
    @IBAction func pressButton1(_ sender: UIButton) {
        var elap = 0.0
        if frogCount != 0 {
            if sender.currentTitle == "X" {
                frogCount -= 1
                elap = Date().timeIntervalSince(startTime)
                sender.setTitle("1", for: UIControl.State.normal)
                displayInterval.text = String(format: "%.2f", elap)
                displayFrogCount.text = String(frogCount)
                buttonUpdate()
            }
        }
    }
    
    @IBAction func pressButton2(_ sender: UIButton) {
        var elap = 0.0
        if frogCount != 0 {
            if sender.currentTitle == "X" {
                frogCount -= 1
                elap = Date().timeIntervalSince(startTime)
                sender.setTitle("2", for: UIControl.State.normal)
                displayInterval.text = String(format: "%.2f", elap)
                displayFrogCount.text = String(frogCount)
                buttonUpdate()
            }
        }
    }
        @IBAction func pressButton3(_ sender: UIButton) {
            var elap = 0.0
            if frogCount != 0 {
                if sender.currentTitle == "X" {
                    frogCount -= 1
                    elap = Date().timeIntervalSince(startTime)
                    sender.setTitle("3", for: UIControl.State.normal)
                    displayInterval.text = String(format: "%.2f", elap)
                    displayFrogCount.text = String(frogCount)
                    buttonUpdate()
                }
            }
        }
        
        @IBAction func pressButton4(_ sender: UIButton) {
            var elap = 0.0
            if frogCount != 0 {
                if sender.currentTitle == "X" {
                    frogCount -= 1
                    elap = Date().timeIntervalSince(startTime)
                    sender.setTitle("4", for: UIControl.State.normal)
                    displayInterval.text = String(format: "%.2f", elap)
                    displayFrogCount.text = String(frogCount)
                    buttonUpdate()
                }
            }
        }
        @IBAction func pressButton5(_ sender: UIButton) {
            var elap = 0.0
            if frogCount != 0 {
                if sender.currentTitle == "X" {
                    frogCount -= 1
                    elap = Date().timeIntervalSince(startTime)
                    sender.setTitle("5", for: UIControl.State.normal)
                    displayInterval.text = String(format: "%.2f", elap)
                    displayFrogCount.text = String(frogCount)
                    buttonUpdate()
                }
            }
        }
        func nextGame() {
            frogCount = 10
            displayFrogCount.text = String(frogCount)
            displayInterval.text = "0"
            button1.setTitle(mark[0], for: UIControl.State.normal)
            button2.setTitle(mark[1], for: UIControl.State.normal)
            button3.setTitle(mark[2], for: UIControl.State.normal)
            button4.setTitle(mark[3], for: UIControl.State.normal)
            button5.setTitle(mark[4], for: UIControl.State.normal)
        }
        func buttonUpdate() {
            let rndNum = arc4random() % 5
            buttonArray[Int(rndNum)].setTitle("X", for: UIControl.State.normal)
        }
        
        
    }

